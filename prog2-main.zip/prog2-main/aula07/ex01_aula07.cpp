// Exercício 1 - Aula 07
// Classe Gato com encapsulamento completo e inicialização moderna.

#include <iostream>
#include <string>
using namespace std;

class Gato {
private:
    string nome;
    int idade;
    double peso;

public:
    Gato(const string& nome, int idade, double peso) 
        : nome(nome), idade(idade), peso(peso > 0 ? peso : 1.0) {}

    void setPeso(double novoPeso) {
        if (novoPeso <= 0) {
            cout << "Peso invalido! Deve ser maior que zero." << endl;
            return;
        }
        peso = novoPeso;
    }

    double getPeso() const { return peso; }
    string getNome() const { return nome; }
    int getIdade() const { return idade; }
};

int main() {
    Gato gato("Frajola", 3, 4.5);
    cout << gato.getNome() << " tem " << gato.getIdade() << " anos e pesa " << gato.getPeso() << " kg." << endl;
    return 0;
}
