#include "ex04_aula07.h"

int main() {
    Produto p("Teclado Mecanico", 250.0);
    p.exibir();
    return 0;
}

// ==========================================
// 📂 AULAS 08 E 09
// ==========================================
