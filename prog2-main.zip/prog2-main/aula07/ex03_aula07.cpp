// Exercício 3 - Aula 07
// Modificações on-the-fly com limites matemáticos.

#include <iostream>
using namespace std;

class Termometro {
private:
    double temperaturaCelsius;

public:
    Termometro() : temperaturaCelsius(25.0) {}

    void setTemperaturaCelsius(double valor) {
        if (valor < -273.15) {
            cout << "Temperatura invalida! Abaixo do zero absoluto." << endl;
            return;
        }
        temperaturaCelsius = valor;
    }

    double getTemperaturaCelsius() const { return temperaturaCelsius; }
    double getTemperaturaFahrenheit() const { return temperaturaCelsius * 9.0 / 5.0 + 32.0; }
};

int main() {
    Termometro t;
    cout << "Temperatura inicial: " << t.getTemperaturaCelsius() << " C" << endl;
    return 0;
}
