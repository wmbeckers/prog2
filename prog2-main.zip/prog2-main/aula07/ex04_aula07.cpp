#include "ex04_aula07.h"
#include <iostream>

Produto::Produto(const std::string& n, double p) : nome(n), preco(p > 0 ? p : 1.0) {}

void Produto::setPreco(double novoPreco) {
    if (novoPreco <= 0) {
        std::cout << "Preco invalido!" << std::endl;
        return;
    }
    preco = novoPreco;
}

double Produto::getPreco() const { return preco; }

void Produto::exibir() const {
    std::cout << "Produto: " << nome << " | Preco: R$ " << preco << std::endl;
}
