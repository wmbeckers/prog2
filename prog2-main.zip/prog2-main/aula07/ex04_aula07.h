#pragma once
#include <string>

class Produto {
private:
    std::string nome;
    double preco;

public:
    Produto(const std::string& n, double p);
    void setPreco(double novoPreco);
    double getPreco() const;
    void exibir() const;
};
