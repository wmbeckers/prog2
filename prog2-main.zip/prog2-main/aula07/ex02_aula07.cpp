// Exercício 2 - Aula 07
// Classe ContaBancaria com segurança de mutabilidade interna.

#include <iostream>
using namespace std;

class ContaBancaria {
private:
    int numeroConta;
    double saldo;

public:
    ContaBancaria(int numeroConta) : numeroConta(numeroConta), saldo(0.0) {}

    void depositar(double valor) {
        if (valor <= 0) {
            cout << "Valor de deposito invalido." << endl;
            return;
        }
        saldo += valor;
    }

    void sacar(double valor) {
        if (valor <= 0 || valor > saldo) {
            cout << "Operacao de saque recusada." << endl;
            return;
        }
        saldo -= valor;
    }

    double getSaldo() const { return saldo; }
    int getNumeroConta() const { return numeroConta; }
};

int main() {
    ContaBancaria conta(12345);
    conta.depositar(1000);
    cout << "Saldo atual: R$ " << conta.getSaldo() << endl;
    return 0;
}
