// Exercício 3 - Aula 04
// Otimização com funções inline.

#include <iostream>
using namespace std;

const double COTACAO_DOLAR = 5.0;

inline double dolarParaReal(double dolares) {
    return dolares * COTACAO_DOLAR;
}

int main() {
    double quantiaDolares;

    cout << "Digite a quantia em dolares: ";
    cin >> quantiaDolares;

    cout << "Quantia convertida: R$ " << dolarParaReal(quantiaDolares) << endl;

    return 0;
}
