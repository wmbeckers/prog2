// Exercício 8 - Aula 04
// Função recursiva com caso base.

#include <iostream>
using namespace std;

long long fatorial(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * fatorial(n - 1);
}

int main() {
    int n;

    cout << "Digite um numero inteiro: ";
    cin >> n;

    cout << n << "! = " << fatorial(n) << endl;

    return 0;
}
