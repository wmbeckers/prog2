// Exercício 7 - Aula 04
// Uso do static_cast com enumerações explicitadas.

#include <iostream>
using namespace std;

enum DiaDaSemana { Domingo, Segunda, Terca, Quarta, Quinta, Sexta, Sabado };

int main() {
    int escolha;

    cout << "Digite um numero de 0 (Domingo) a 6 (Sabado): ";
    cin >> escolha;

    DiaDaSemana dia = static_cast<DiaDaSemana>(escolha);

    switch (dia) {
        case Domingo: cout << "Domingo" << endl; break;
        case Segunda: cout << "Segunda-feira" << endl; break;
        case Terca:   cout << "Terca-feira" << endl; break;
        case Quarta:  cout << "Quarta-feira" << endl; break;
        case Quinta:  cout << "Quinta-feira" << endl; break;
        case Sexta:   cout << "Sexta-feira" << endl; break;
        case Sabado:  cout << "Sabado" << endl; break;
        default:      cout << "Numero invalido" << endl;
    }

    return 0;
}
