// Exercício 11 - Aula 04
// Funções com parâmetros opcionais (Valores default).

#include <iostream>
using namespace std;

void imprimeCaracteres(char c = '#', int quantidade = 50) {
    for (int i = 0; i < quantidade; i++) {
        cout << c;
    }
    cout << endl;
}

int main() {
    imprimeCaracteres();
    imprimeCaracteres('*');
    imprimeCaracteres('-', 20);

    return 0;
}

// ==========================================
// 📂 AULA 05
// ==========================================
