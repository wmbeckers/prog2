// Exercício 5 - Aula 04
// Structs e arrays de estruturas heterogêneas (Otimizado com getline).

#include <iostream>
#include <string>
using namespace std;

struct Aluno {
    string nome;
    double nota1;
    double nota2;
};

int main() {
    const int QTD_ALUNOS = 3;
    Aluno alunos[QTD_ALUNOS];

    for (int i = 0; i < QTD_ALUNOS; i++) {
        cout << "Aluno " << (i + 1) << endl;
        cout << "Nome: ";
        if (i == 0) cin.ignore(); 
        getline(cin, alunos[i].nome);
        cout << "Nota 1: ";
        cin >> alunos[i].nota1;
        cout << "Nota 2: ";
        cin >> alunos[i].nota2;
        cin.ignore(); 
    }

    cout << "\nMedias:" << endl;
    for (int i = 0; i < QTD_ALUNOS; i++) {
        double media = (alunos[i].nota1 + alunos[i].nota2) / 2;
        cout << alunos[i].nome << ": " << media << endl;
    }

    return 0;
}
