// Exercício 9 - Aula 04
// Passagem por referência usando referências nativas (int&).

#include <iostream>
using namespace std;

void trocar(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}

int main() {
    int x, y;

    cout << "Digite o primeiro valor: ";
    cin >> x;
    cout << "Digite o segundo valor: ";
    cin >> y;

    cout << "\nAntes de trocar: x = " << x << ", y = " << y << endl;

    trocar(x, y);

    cout << "Depois de trocar: x = " << x << ", y = " << y << endl;

    return 0;
}
