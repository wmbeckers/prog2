// Exercício 1 - Aula 04
// Entrada e saída de datas.

#include <iostream>
using namespace std;

int main() {
    int dia, mes, ano;

    cout << "Digite o dia: ";
    cin >> dia;
    cout << "Digite o mes: ";
    cin >> mes;
    cout << "Digite o ano: ";
    cin >> ano;

    cout << "Data informada: " << dia << "/" << mes << "/" << ano << endl;

    return 0;
}
