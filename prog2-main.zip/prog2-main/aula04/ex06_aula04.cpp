// Exercício 6 - Aula 04
// Redimensionamento de Arrays Dinâmicos crús no Heap.

#include <iostream>
using namespace std;

int* adicionarElemento(int* arr, int& tamanho, int valor) {
    int* novoArr = new int[tamanho + 1];

    for (int i = 0; i < tamanho; i++) {
        novoArr[i] = arr[i];
    }
    novoArr[tamanho] = valor;

    delete[] arr;
    tamanho++;

    return novoArr;
}

int* removerElemento(int* arr, int& tamanho, int indice) {
    if (indice < 0 || indice >= tamanho) {
        cout << "Indice invalido." << endl;
        return arr;
    }

    int* novoArr = new int[tamanho - 1];

    for (int i = 0, j = 0; i < tamanho; i++) {
        if (i != indice) {
            novoArr[j++] = arr[i];
        }
    }

    delete[] arr;
    tamanho--;

    return novoArr;
}

void exibirArray(const int* arr, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int tamanho = 3;
    int* arr = new int[tamanho]{10, 20, 30};

    cout << "Array inicial: ";
    exibirArray(arr, tamanho);

    arr = adicionarElemento(arr, tamanho, 40);
    cout << "Apos adicionar 40: ";
    exibirArray(arr, tamanho);

    arr = removerElemento(arr, tamanho, 1);
    cout << "Apos remover indice 1: ";
    exibirArray(arr, tamanho);

    delete[] arr;

    return 0;
}
