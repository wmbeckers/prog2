// Exercício 2 - Aula 04
// Passagem de parâmetros simples por valor.

#include <iostream>
using namespace std;

int soma(int a, int b) {
    return a + b;
}

int main() {
    int valor1, valor2;

    cout << "Digite o primeiro valor: ";
    cin >> valor1;
    cout << "Digite o segundo valor: ";
    cin >> valor2;

    cout << "Soma: " << soma(valor1, valor2) << endl;

    return 0;
}
