// Exercício 10 - Aula 04
// Sobrecarga de funções (Overloading).

#include <iostream>
using namespace std;

int calculaQuadrado(int x) {
    return x * x;
}

double calculaQuadrado(double x) {
    return x * x;
}

int main() {
    int valorInteiro;
    double valorDecimal;

    cout << "Digite um numero inteiro: ";
    cin >> valorInteiro;
    cout << "Digite um numero decimal: ";
    cin >> valorDecimal;

    cout << "Quadrado do inteiro: " << calculaQuadrado(valorInteiro) << endl;
    cout << "Quadrado do decimal: " << calculaQuadrado(valorDecimal) << endl;

    return 0;
}
