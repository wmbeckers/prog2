// Exercício 1 - Aula 01
// Escreva um programa que mostre: Bem-vindo ao C++!

#include <iostream>
using namespace std;

int main() {
    cout << "Bem-vindo ao C++!" << endl;
    return 0;
}
