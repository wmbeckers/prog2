// Exercício 2 - Aula 01
// Modifique o programa para exibir seu nome.

#include <iostream>
#include <string>
using namespace std;

int main() {
    string nome;

    cout << "Digite seu nome: ";
    getline(cin, nome);

    cout << "Bem-vindo ao C++, " << nome << "!" << endl;

    return 0;
}
