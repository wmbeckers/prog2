// Exercício 4 - Aula 01
// Erro de compilação x erro de execução.

#include <iostream>
using namespace std;

int main() {
    int dividendo, divisor;

    cout << "Digite o dividendo: ";
    cin >> dividendo;
    cout << "Digite o divisor: ";
    cin >> divisor;

    if (divisor == 0) {
        cout << "Erro: divisao por zero e um erro de execucao (runtime)." << endl;
        cout << "O programa compilou normalmente, mas essa operacao nao pode ser realizada." << endl;
        return 1;
    }

    cout << dividendo << " / " << divisor << " = " << (dividendo / divisor) << endl;

    return 0;
}

// ==========================================
// 📂 AULA 02
// ==========================================
