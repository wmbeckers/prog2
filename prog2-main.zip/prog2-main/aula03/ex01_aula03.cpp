// Exercício 1 - Aula 03
// Maioridade e validação lógica.

#include <iostream>
using namespace std;

int main() {
    int idade;
    int temCarteiraInt;

    cout << "Digite sua idade: ";
    cin >> idade;

    if (idade >= 18) {
        cout << "Maior de idade" << endl;
    } else {
        cout << "Menor de idade" << endl;
    }

    cout << "Possui carteira de habilitacao? (1-sim, 0-nao): ";
    cin >> temCarteiraInt;
    bool temCarteira = (temCarteiraInt == 1);

    if (idade >= 18 && temCarteira) {
        cout << "Pode dirigir" << endl;
    } else {
        cout << "Nao pode dirigir" << endl;
    }

    return 0;
}
