// Exercício 4 - Aula 03
// Loops do-while e while.

#include <iostream>
using namespace std;

int main() {
    int numero;

    do {
        cout << "Digite um numero inteiro positivo: ";
        cin >> numero;
        if (numero <= 0) {
            cout << "Valor invalido, tente novamente." << endl;
        }
    } while (numero <= 0);

    int i = 1;
    cout << "Contagem de 1 ate " << numero << ": ";
    while (i <= numero) {
        cout << i << " ";
        i++;
    }
    cout << endl;

    return 0;
}
