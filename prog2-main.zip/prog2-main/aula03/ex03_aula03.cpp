// Exercício 3 - Aula 03
// Menu simples usando switch.

#include <iostream>
using namespace std;

int main() {
    int opcao;

    cout << "1 - Cadastrar" << endl;
    cout << "2 - Listar" << endl;
    cout << "3 - Sair" << endl;
    cout << "Escolha uma opcao: ";
    cin >> opcao;

    switch (opcao) {
        case 1:
            cout << "Cadastrar" << endl;
            break;
        case 2:
            cout << "Listar" << endl;
            break;
        case 3:
            cout << "Sair" << endl;
            break;
        default:
            cout << "Opcao invalida" << endl;
    }

    return 0;
}
