// Exercício 5 - Aula 03
// Cálculo do fatorial usando laço for.

#include <iostream>
using namespace std;

int main() {
    int n;
    long long fatorial = 1;

    cout << "Digite um numero inteiro: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        fatorial *= i;
    }

    cout << n << "! = " << fatorial << endl;

    return 0;
}
