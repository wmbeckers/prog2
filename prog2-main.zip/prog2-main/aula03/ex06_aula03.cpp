// Exercício 6 - Aula 03
// Laços for aninhados (Tabuada).

#include <iostream>
using namespace std;

int main() {
    for (int n = 1; n <= 10; n++) {
        for (int m = 1; m <= 10; m++) {
            cout << n << " x " << m << " = " << (n * m) << endl;
        }
        cout << endl;
    }

    return 0;
}

// ==========================================
// 📂 AULA 04
// ==========================================
