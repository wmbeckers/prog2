// Exercício 2 - Aula 03
// Classificação com if / else if / else.

#include <iostream>
using namespace std;

int main() {
    double nota;

    cout << "Digite a nota final do aluno: ";
    cin >> nota;

    if (nota >= 7) {
        cout << "Aprovado" << endl;
    } else if (nota >= 5) {
        cout << "Recuperacao" << endl;
    } else {
        cout << "Reprovado" << endl;
    }

    return 0;
}
