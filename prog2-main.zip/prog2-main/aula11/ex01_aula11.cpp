// Exercício 1 - Aula 11
// Hierarquia de escopos complexos via namespaces aninhados estruturados.

#include <iostream>
using namespace std;

namespace Geometria::Bidimensional {
    const double PI = 3.14159;
    double calcularArea(double raio) { return PI * raio * raio; }
}

int main() {
    double area = Geometria::Bidimensional::calcularArea(5.0);
    cout << "Area: " << area << endl;
    return 0;
}
