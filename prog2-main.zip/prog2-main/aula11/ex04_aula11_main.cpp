#include "ex04_aula11.h"

int main() {
    Livro l("O Senhor dos Aneis", "J.R.R. Tolkien");
    l.exibir();
    return 0;
}
