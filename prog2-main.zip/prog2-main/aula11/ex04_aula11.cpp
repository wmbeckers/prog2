#include "ex04_aula11.h"
#include <iostream>

Livro::Livro(const std::string& t, const std::string& a) : titulo(t), autor(a) {}

void Livro::exibir() const {
    std::cout << "\"" << titulo << "\" - " << autor << std::endl;
}
