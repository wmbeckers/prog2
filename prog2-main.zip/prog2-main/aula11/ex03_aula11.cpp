// Exercício 3 - Aula 11
// Tratamento de exceções robusto com barreira try/catch.

#include <iostream>
#include <stdexcept>
using namespace std;

double dividir(double a, double b) {
    if (b == 0) {
        throw runtime_error("Divisao por zero nao e permitida");
    }
    return a / b;
}

int main() {
    try {
        double res = dividir(10, 0);
    } catch (const runtime_error& e) {
        cout << "Excecao interceptada: " << e.what() << endl;
    }
    return 0;
}
