#pragma once
#include <string>

class Livro {
private:
    std::string titulo;
    std::string autor;

public:
    Livro(const std::string& t, const std::string& a);
    void exibir() const;
};
