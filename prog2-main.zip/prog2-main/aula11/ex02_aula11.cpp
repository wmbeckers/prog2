// Exercício 2 - Aula 11
// Funções amigas (friend) e sobrecarga externa de fluxos de E/S.

#include <iostream>
using namespace std;

class Retangulo {
private:
    double largura;
    double altura;

public:
    Retangulo(double l, double a) : largura(l), altura(a) {}

    friend ostream& operator<<(ostream& os, const Retangulo& r);
};

ostream& operator<<(ostream& os, const Retangulo& r) {
    os << "Retangulo [" << r.largura << " x " << r.altura << "]";
    return os;
}

int main() {
    Retangulo r(4.0, 7.0);
    cout << r << endl;
    return 0;
}
