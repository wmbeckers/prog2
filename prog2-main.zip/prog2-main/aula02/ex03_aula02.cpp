// Exercício 3 - Aula 02
// Conversões explícitas com static_cast, to_string e stoi.

#include <iostream>
#include <string>
using namespace std;

int main() {
    double valorDecimal;
    cout << "Digite um numero decimal: ";
    cin >> valorDecimal;

    int valorInteiro = static_cast<int>(valorDecimal);
    cout << "Convertido para int: " << valorInteiro << endl;

    string valorTexto = to_string(valorInteiro);
    cout << "Convertido para string: " << valorTexto << endl;

    string entradaTexto;
    cout << "Digite um numero em formato de texto: ";
    cin >> entradaTexto;

    int valorConvertido = stoi(entradaTexto);
    cout << "String convertida de volta para int: " << valorConvertido << endl;

    return 0;
}
