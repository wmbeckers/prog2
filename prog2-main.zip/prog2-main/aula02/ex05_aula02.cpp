// Exercício 5 - Aula 02
// Operadores aritméticos, lógicos, relacionais e bitwise.

#include <iostream>
using namespace std;

int main() {
    int a = 12, b = 5;

    cout << "a = " << a << ", b = " << b << endl;

    cout << "\nOperadores aritmeticos:" << endl;
    cout << "Soma: " << a + b << endl;
    cout << "Subtracao: " << a - b << endl;
    cout << "Multiplicacao: " << a * b << endl;
    cout << "Divisao: " << a / b << endl;
    cout << "Resto: " << a % b << endl;

    cout << "\nOperadores relacionais e logicos:" << endl;
    cout << "Maior? " << (a > b) << endl;
    cout << "Igual? " << (a == b) << endl;
    cout << "E logico? " << (a > 0 && b > 0) << endl;

    cout << "\nOperadores bitwise:" << endl;
    cout << "AND (a & b): " << (a & b) << endl;
    cout << "OR (a | b): " << (a | b) << endl;
    cout << "XOR (a ^ b): " << (a ^ b) << endl;
    cout << "Deslocamento a esquerda (a << 1): " << (a << 1) << endl;
    cout << "Deslocamento a direita (a >> 1): " << (a >> 1) << endl;

    return 0;
}
