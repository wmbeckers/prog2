// Exercício 1 - Aula 02
// Variáveis e constantes.

#include <iostream>
using namespace std;

int main() {
    int idade = 20;
    float altura = 1.75f;
    char inicial = 'A';
    bool aprovado = true;
    const double PI = 3.14159;

    cout << "Idade: " << idade << endl;
    cout << "Altura: " << altura << endl;
    cout << "Inicial: " << inicial << endl;
    cout << boolalpha << "Aprovado: " << aprovado << endl;
    cout << "PI: " << PI << endl;

    return 0;
}
