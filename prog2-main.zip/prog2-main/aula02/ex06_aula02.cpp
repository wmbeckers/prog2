// Exercício 6 - Aula 02
// Limpeza do buffer de entrada com cin.ignore().

#include <iostream>
#include <string>
using namespace std;

int main() {
    int idade;
    string nomeCompleto;

    cout << "Digite sua idade: ";
    cin >> idade;

    cin.ignore(); // descarta o '\n' deixado no buffer pelo cin >>

    cout << "Digite seu nome completo: ";
    getline(cin, nomeCompleto);

    cout << "\nNome: " << nomeCompleto << endl;
    cout << "Idade: " << idade << endl;

    return 0;
}

// ==========================================
// 📂 AULA 03
// ==========================================
