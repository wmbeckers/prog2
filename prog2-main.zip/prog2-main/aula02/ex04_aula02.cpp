// Exercício 4 - Aula 02
// Namespaces para evitar conflitos de nomes.

#include <iostream>
using namespace std;

namespace portugues {
    void saudacao() {
        cout << "Ola, bem-vindo!" << endl;
    }
}

namespace ingles {
    void saudacao() {
        cout << "Hello, welcome!" << endl;
    }
}

int main() {
    portugues::saudacao();
    ingles::saudacao();

    return 0;
}
