// Exercício 2 - Aula 02
// Conceito de escopo de variáveis.

#include <iostream>
using namespace std;

int contador = 0; // variável global

void incrementaGlobal() {
    int contador = 100; // variável local
    contador++;
    cout << "Contador local dentro da funcao: " << contador << endl;

    ::contador++; // acessa explicitamente a variável global
}

int main() {
    int contador = 5; // variável local do main

    cout << "Contador local no main: " << contador << endl;
    cout << "Contador global antes: " << ::contador << endl;

    incrementaGlobal();

    cout << "Contador global depois: " << ::contador << endl;
    cout << "Contador local no main (inalterado): " << contador << endl;

    return 0;
}
