// Exercício 1 - Aula 06
// Ponteiros Inteligentes Exclusivos (std::unique_ptr).

#include <iostream>
#include <memory>
using namespace std;

int main() {
    int valor;

    cout << "Digite um valor inteiro: ";
    cin >> valor;

    unique_ptr<int> ptr = make_unique<int>(valor);

    cout << "Valor armazenado: " << *ptr << endl;

    *ptr = *ptr * 2;
    cout << "Valor dobrado: " << *ptr << endl;

    return 0;
}
