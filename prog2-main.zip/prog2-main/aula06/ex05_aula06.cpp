// Exercício 5 - Aula 06
// Gerenciamento compartilhado e cíclico (shared_ptr e weak_ptr).

#include <iostream>
#include <memory>
using namespace std;

int main() {
    shared_ptr<int> sp1 = make_shared<int>(42);
    cout << "Apos criar sp1, use_count: " << sp1.use_count() << endl;

    {
        shared_ptr<int> sp2 = sp1;
        cout << "Apos criar sp2, use_count: " << sp1.use_count() << endl;
    } 

    cout << "Apos sp2 sair de escopo, use_count: " << sp1.use_count() << endl;

    weak_ptr<int> wp = sp1;
    cout << "use_count apos criar weak_ptr (nao altera): " << sp1.use_count() << endl;

    if (auto spt = wp.lock()) {
        cout << "Valor observado via weak_ptr: " << *spt << endl;
    }

    return 0;
}

// ==========================================
// 📂 AULA 07
// ==========================================
