// Exercício 2 - Aula 06
// Lista duplamente encadeada da STL (std::list).

#include <iostream>
#include <list>
using namespace std;

int main() {
    list<int> minhaLista;
    int valor;
    int opcao;

    while (true) {
        cout << "\nDigite um valor (0 para encerrar): ";
        cin >> valor;
        if (valor == 0) break;

        cout << "Inserir no inicio (1) ou no final (2)? ";
        cin >> opcao;

        if (opcao == 1) {
            minhaLista.push_front(valor);
        } else {
            minhaLista.push_back(valor);
        }
    }

    cout << "\nElementos da lista: ";
    for (int v : minhaLista) {
        cout << v << " ";
    }
    cout << endl;

    cout << "Tamanho da lista: " << minhaLista.size() << endl;

    return 0;
}
