// Exercício 3 - Aula 06
// Fila de atendimento FIFO (std::queue).

#include <iostream>
#include <queue>
#include <string>
using namespace std;

int main() {
    queue<string> filaAtendimento;
    string nome;

    cout << "Cadastro de clientes na fila (digite 'fim' para encerrar):" << endl;
    while (true) {
        cout << "Nome do cliente: ";
        cin >> nome;
        if (nome == "fim") break;
        filaAtendimento.push(nome);
    }

    cout << "\nOrdem de atendimento:" << endl;
    int posicao = 1;
    while (!filaAtendimento.empty()) {
        cout << posicao << "º - Atendendo: " << filaAtendimento.front() << endl;
        filaAtendimento.pop();
        posicao++;
    }

    cout << "Fila de atendimento vazia." << endl;

    return 0;
}
