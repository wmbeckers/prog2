// Exercício 4 - Aula 06
// Validação LIFO de delimitadores com pilhas (std::stack).

#include <iostream>
#include <stack>
#include <string>
using namespace std;

int main() {
    stack<char> pilha;
    string expressao;
    bool balanceada = true;

    cout << "Digite uma expressao: ";
    cin.ignore();
    getline(cin, expressao);

    for (char c : expressao) {
        if (c == '(') {
            pilha.push(c);
        } else if (c == ')') {
            if (pilha.empty()) {
                balanceada = false;
                break;
            }
            pilha.pop();
        }
    }

    if (!pilha.empty()) {
        balanceada = false;
    }

    if (balanceada) {
        cout << "Expressao balanceada!" << endl;
    } else {
        cout << "Expressao NAO balanceada!" << endl;
    }

    return 0;
}
