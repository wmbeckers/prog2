// Exercício 1 - Aula 8-9
// Deep Copy controlada em matrizes dinâmicas.

#include <iostream>
using namespace std;

class MatrizDinamica {
private:
    int linhas;
    int colunas;
    int** dados;

    int** alocar(int l, int c) {
        int** m = new int*[l];
        for (int i = 0; i < l; i++) {
            m[i] = new int[c]();
        }
        return m;
    }

public:
    MatrizDinamica(int l, int c) : linhas(l), colunas(c) {
        dados = alocar(linhas, colunas);
    }

    MatrizDinamica(const MatrizDinamica& outra) : linhas(outra.linhas), colunas(outra.colunas) {
        dados = alocar(linhas, colunas);
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                dados[i][j] = outra.dados[i][j];
            }
        }
    }

    ~MatrizDinamica() {
        for (int i = 0; i < linhas; i++) {
            delete[] dados[i];
        }
        delete[] dados;
    }

    void definir(int i, int j, int valor) { dados[i][j] = valor; }
    void exibir() const {
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) { cout << dados[i][j] << " "; }
            cout << endl;
        }
    }
};

int main() {
    MatrizDinamica m1(2, 2);
    m1.definir(0, 0, 5);
    MatrizDinamica m2 = m1; 
    return 0;
}
