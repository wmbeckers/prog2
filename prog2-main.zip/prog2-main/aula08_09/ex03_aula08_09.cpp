// Exercício 3 - Aula 8-9
// Semântica de Movimento e exclusão de cópias primitivas.

#include <iostream>
#include <string>
#include <utility>
using namespace std;

class StringSegura {
private:
    string dados;

public:
    StringSegura(string texto) : dados(std::move(texto)) {}

    StringSegura(const StringSegura& outra) = delete;
    StringSegura& operator=(const StringSegura& outra) = delete;

    StringSegura(StringSegura&& outra) = default;
    StringSegura& operator=(StringSegura&& outra) = default;

    void exibir() const { cout << dados << endl; }
};

int main() {
    StringSegura s1("Exclusivo");
    StringSegura s2 = std::move(s1);
    return 0;
}

// ==========================================
// 📂 AULA 10
// ==========================================
