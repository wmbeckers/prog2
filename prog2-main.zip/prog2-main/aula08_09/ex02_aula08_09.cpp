// Exercício 2 - Aula 8-9
// Sobrecarga de Operadores de Incremento Pré e Pós-fixados.

#include <iostream>
using namespace std;

class Contador {
private:
    int valor;

public:
    Contador(int valorInicial = 0) : valor(valorInicial) {}

    Contador& operator++() {
        valor++;
        return *this;
    }

    Contador operator++(int) {
        Contador copia = *this;
        valor++;
        return copia;
    }

    int getValor() const { return valor; }
};

int main() {
    Contador c(10);
    ++c;
    c++;
    return 0;
}
