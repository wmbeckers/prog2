// Exercício 5 - Aula 05
// Ponteiros para funções (Function Pointers).

#include <iostream>
using namespace std;

int soma(int a, int b) { return a + b; }
int subtrai(int a, int b) { return a - b; }

int main() {
    int opcao, x, y;
    int (*operacao)(int, int) = nullptr;

    cout << "1 - Soma" << endl;
    cout << "2 - Subtracao" << endl;
    cout << "Escolha a operacao: ";
    cin >> opcao;

    cout << "Digite dois valores: ";
    cin >> x >> y;

    if (opcao == 1) {
        operacao = soma;
    } else {
        operacao = subtrai;
    }

    if (operacao != nullptr) {
        cout << "Resultado: " << operacao(x, y) << endl;
    }

    return 0;
}

// ==========================================
// 📂 AULA 06
// ==========================================
