// Exercício 3 - Aula 05
// Alocação dinâmica básica de arrays no Heap.

#include <iostream>
using namespace std;

int main() {
    int tamanho;

    cout << "Quantos elementos deseja alocar? ";
    cin >> tamanho;

    int* v = new int[tamanho];

    for (int i = 0; i < tamanho; i++) {
        cout << "Valor " << (i + 1) << ": ";
        cin >> v[i];
    }

    cout << "Array: ";
    for (int i = 0; i < tamanho; i++) {
        cout << v[i] << " ";
    }
    cout << endl;

    delete[] v;

    return 0;
}
