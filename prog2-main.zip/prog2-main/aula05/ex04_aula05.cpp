// Exercício 4 - Aula 05
// Passagem e modificação de dados via ponteiro crú (int*).

#include <iostream>
using namespace std;

void incrementa(int* p) {
    if (p != nullptr) {
        (*p)++;
    }
}

int main() {
    int x;

    cout << "Digite um numero: ";
    cin >> x;

    cout << "Antes de incrementar: " << x << endl;

    incrementa(&x);

    cout << "Depois de incrementar: " << x << endl;

    return 0;
}
