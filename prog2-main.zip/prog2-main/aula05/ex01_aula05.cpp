// Exercício 1 - Aula 05
// Endereços de memória e operador de desreferência.

#include <iostream>
using namespace std;

int main() {
    int x = 10;
    int y = 20;

    cout << "x = " << x << " | endereco de x: " << &x << endl;
    cout << "y = " << y << " | endereco de y: " << &y << endl;

    return 0;
}
