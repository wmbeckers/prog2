// Exercício 2 - Aula 05
// Aritmética de ponteiros pura.

#include <iostream>
using namespace std;

const int TAM = 100;

int main() {
    double a[TAM];
    double *aPtr = a;
    int n;
    double soma = 0.0;

    cout << "Quantos valores deseja digitar (max " << TAM << ")? ";
    cin >> n;
    if (n > TAM) n = TAM;

    for (int j = 0; j < n; j++) {
        cout << "Valor " << (j + 1) << ": ";
        cin >> *(a + j);
    }

    for (int j = 0; j < n; j++) {
        soma += *(aPtr + j);
    }

    double media = soma / n;

    cout << "Soma: " << soma << endl;
    cout << "Media: " << media << endl;

    return 0;
}
