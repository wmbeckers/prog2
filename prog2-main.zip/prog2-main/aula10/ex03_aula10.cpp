// Exercício 3 - Aula 10
// Polimorfismo dinâmico e Late Binding com VTable e Destrutor Virtual.

#include <iostream>
#include <string>
using namespace std;

class Veiculo {
public:
    string marca;

    virtual void emitirSom() {
        cout << "Vrum... (ruido generico)" << endl;
    }
    virtual ~Veiculo() = default; 
};

class Carro : public Veiculo {
public:
    int numeroPortas;

    void emitirSom() override {
        cout << "Fom fom! (buzina real)" << endl;
    }
};

int main() {
    Carro carroReal;
    Veiculo* ptr = &carroReal;
    ptr->emitirSom(); 
    return 0;
}

// ==========================================
// 📂 AULA 11
// ==========================================
