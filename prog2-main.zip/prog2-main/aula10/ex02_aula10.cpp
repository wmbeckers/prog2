// Exercício 2 - Aula 10
// Configuração de assinaturas dinâmicas via métodos virtuais.

#include <iostream>
#include <string>
using namespace std;

class Veiculo {
public:
    string marca;

    virtual void emitirSom() {
        cout << "Vrum... (ruido generico)" << endl;
    }
    virtual ~Veiculo() = default;
};

class Carro : public Veiculo {
public:
    int numeroPortas;
};

int main() {
    Carro c;
    c.emitirSom();
    return 0;
}
