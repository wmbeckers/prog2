// Exercício 1 - Aula 10
// Herança pública simples.

#include <iostream>
#include <string>
using namespace std;

class Veiculo {
public:
    string marca;
};

class Carro : public Veiculo {
public:
    int numeroPortas;
};

int main() {
    Carro c;
    c.marca = "Ford";
    c.numeroPortas = 2;
    return 0;
}
